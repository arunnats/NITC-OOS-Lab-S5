public class Q2 {
    public static void main(String[] args) {
        String str = "Woah, object oriented programming";
        String substr1 = "oriented";
        String substr2 = "Woah";
        System.out.println(str.replaceAll(substr1, substr2));
    }
}

