package Q10.company;

public class Employee {
  protected String name;

  public Employee(String name) {
      this.name = name;
  }

  public String getName() {
      return name;
  }
}